import requests
from bs4 import BeautifulSoup
import subprocess

# Step 1: Function to scrape the README file from a GitHub repository
def scrape_github_readme(repo_url):
    # GitHub URL format for the README file
    url = repo_url.rstrip('/') + '/blob/main/README.md'
    
    # Send a request to the GitHub URL
    response = requests.get(url)
    if response.status_code != 200:
        print("Failed to retrieve the page.")
        return None
    
    # Parse the page content
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find the div containing the README file
    readme_div = soup.find('article')
    if not readme_div:
        print("README content not found.")
        return None

    # Extract text and ignore images
    readme_text = ''.join([p.get_text() for p in readme_div.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'code'])])

    return readme_text

# Step 2: Function to interact with the LLaMA model via Ollama CLI
def run_llama_analysis(prompt):
    # Start the ollama process and pass the prompt
    process = subprocess.Popen(
        ['ollama', 'run', 'llama3.1'],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding='utf-8'
    )

    # Send the prompt to LLaMA
    output, error = process.communicate(input=prompt)
    
    if error:
        print("Error:", error)
    return output

# Step 3: Main function to combine scraping and LLaMA analysis
def main():
    # Get the GitHub repo link from the user
    repo_url = input("Enter the GitHub repository URL: ")
    readme_text = scrape_github_readme(repo_url)
    
    if readme_text:
        print("\nExtracted README content:\n")
        print(readme_text)
        
        # Construct the prompt for LLaMA based on the scraped README content
        prompt = f"Based on the following README content, list the primary technical skills required to contribute to this project:\n\n{readme_text}"
        
        # Run LLaMA with the constructed prompt
        print("\nSending to LLaMA for analysis...\n")
        llama_response = run_llama_analysis(prompt)
        
        # Display LLaMA's response
        print("LLaMA Response:\n")
        print(llama_response)

# Run the main function
if __name__ == "__main__":
    main()
